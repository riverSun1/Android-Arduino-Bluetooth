# TimeInterrupt

This library allows for use of timer interrupts on various Arduino compatible microcontrollers.
Read HowToUse.pdf for information on how to use this library. Example sketches have been provided.

Compatible controllers:
  -ATmega168/328P/2560/1280/32U4
  -ATtiny25/45/85
